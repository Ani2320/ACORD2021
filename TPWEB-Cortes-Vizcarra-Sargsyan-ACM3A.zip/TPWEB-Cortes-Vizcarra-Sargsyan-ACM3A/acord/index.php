<?php
require_once("consultas/coneccion.php");
require_once("include/funciones.php");
require_once("include/1head.php");
require_once("include/2header.php");
require_once("include/carrusel.php");
require_once("include/form_registro_usuario.php");
require_once("include/form_ingreso_usuario.php");
mostrar_productos($con);
?>



<?php require_once("include/footer.php");  ?>

</body>

</html>