<body onload="loadDoc()">
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark dark">
            <div class="container col-10">
                <a class="navbar-brand acord" href="<?php echo $punto . "index.php" ?>"> <span class="marca ">Acord</span> </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav col-8 ">
                        <?php nav_menu(menu($con), $indice, $punto); ?>
                    </div>

                    <div class="d-flex col-5 align-items-center">
                        <div class="d-flex" id="bienvenida"></div>
                        <div class=" p-2 " id="nada"></div>
                        <div class="d-flex menu_gral" id="nadados"></div>
                    </div>
                </div>
            </div>
         
        </nav>
        <div class="container-fluid d-flex justify-content-center nav2"> 
          <?php menuCategorias(categorias($con),$punto) ?>
        </div>
</div>
    </header>
    <span></span>