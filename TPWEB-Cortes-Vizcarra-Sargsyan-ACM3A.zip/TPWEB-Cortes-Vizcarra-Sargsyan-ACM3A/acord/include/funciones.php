<?php
function LeerArrayJson($carpeta)
{
  $fp  = fopen($carpeta, 'r');
  $json =  fread($fp, filesize($carpeta));
  fclose($fp);
  return  json_decode($json, true);
}
function GrabarArrayJson($carpeta, $array)
{
  if (!file_exists($carpeta)) {
    mkdir($carpeta);
    $fp  = fopen($carpeta, 'w');
    fwrite($fp, json_encode($array));
    fclose($fp);
  }
  $fp  = fopen($carpeta, 'w');
  fwrite($fp, json_encode($array));
  fclose($fp);
}
function nav_menu($array, $num, $punto)
{
  for ($i = 0; $i < count($array); $i++) {
    $active = "";
    if ($num == $i + 1) {
      $active = "active";
    }

    echo  '<a class="nav-link ' . $active . ' menues" href="' . $punto . $array[$i]['referencia'] . '?p=' . ($i + 1) . '">' . $array[$i]['nombre'] . '</a>';
  }
}
function columa_img($array, $punto)
{

  foreach ($array as $elemento1 => $value) {
    foreach ($value as $elemento2 => $value) {
      echo  '<div class="borde" ><img class="colun" src="' . $punto . $value . '" alt=""></div>';
    }
  }
}
function detalle($cone, $id_pro)
{
  if ($cone) {
    $query = "SELECT de.id_detalle_producto,de.nombre as nombrep,de.descripcion,de.precio,al.cantidad,de.valoracion
              FROM detalle_producto de
              inner join almacen al on de.id_detalle_producto=al.id_detalle_producto
              where de.id_detalle_producto='$id_pro'";

    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_detalle_producto" => $row['id_detalle_producto'],
        "nombrep" => $row['nombrep'],
        "descripcion" => $row['descripcion'],
        "precio" => $row['precio'],
        "cantidad" => $row['cantidad'],
        "valoracion" =>$row ['valoracion']
      );
    }
  }
  return $arreglo;
}
function referencia($cone, $id_pro)
{
  $query1 = "SELECT img.referencia
  from img 
  inner join imagenes on img.id_img=imagenes.id_img
  where imagenes.id_detalle_producto=$id_pro";
  $result = mysqli_query($cone, $query1);
  $referencia = array();
  while ($row = mysqli_fetch_array($result)) {
    $referencia[] = array(
      "referencia" => $row['referencia']
    );
  }
  return $referencia;
}
function menu($cone)
{
  if ($cone) {
    $query = "SELECT*FROM menu";
    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_menu" => $row['id_menu'],
        "referencia" => $row['referencia'],
        "nombre" => $row['nombre']
      );
    }
  }
  return $arreglo;
}
function categorias($cone)
{
  if ($cone) {
    $query = "SELECT*FROM categoria";
    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_categoria" => $row['id_categoria'],
        "nombre" => $row['nombre'],

      );
    }
  }
  return $arreglo;
}

function buscarUsuario($cone, $email)
{

  if ($cone) {
    $query = "SELECT*FROM usuario u where u.email='$email'";
    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_usuario" => $row['id_usuario'],
        "nombre" => $row['nombre'],
        "apellido" => $row['apellido'],
        "email" => $row['email'],
        "clave" => $row['clave']
      );
    }
  }


  return $arreglo;
}
function interes($precio)
{
  $valor = ($precio + ($precio * 0.05)) / 12;
  return $valor;
}
function detalle_compra($array, $array2, $punto)
{
  echo '<div class="comprafutura d-flex pt-3 pl-3 ">';
  echo '<div class="chiqui ml-5"><img src="' . $punto . $array2[0]['referencia'] . '" width="60" height="60" alt=""></div>';
  echo '<div class=" til ml-5"><a href="detalle_producto.php?p=2&pr=' . $array[0]['id_detalle_producto'] . '"><span>' . $array[0]['nombrep'] . '</span></a></div>';
  echo '<div class=" flex-colum ml-5">';
  echo '<div> <span>Precio:</span></div>';
  echo '<div> <span> ' . $array[0]['precio'] . '</span></div>';
  echo '</div>';
  echo '<div class=" flex-colum ml-5">';
  echo '<div> <span>Cantidad:</span></div>';
  echo '<div> <span>$' . $array[0]['precio'] . '</span></div>';
  echo '</div>';
  echo '<div class=" flex-colum ml-5 subt">';
  echo '<div> <span>SubTotal:</span></div>';
  echo '<div> <span>$' . $array[0]['precio'] . '</span></div>';
  echo '</div>';
  echo '</div>';
}

function buscar_lista_compra($cone, $id)
{
  if ($cone) {
    $query = "SELECT po.id_posibles_compras,u.nombre,p.id_detalle_producto,p.nombre as nombrep,p.precio
  from posibles_compras po
  inner join usuario u on po.id_usuario=u.id_usuario
  inner join detalle_producto p on po.id_detalle_producto=p.id_detalle_producto
  where u.id_usuario='$id'";

    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_posibles_compras" => $row['id_posibles_compras'],
        "nombre" => $row['nombre'],
        "id_detalle_producto" => $row['id_detalle_producto'],
        "nombrep" => $row['nombrep'],
        "precio" => $row['precio']

      );
    }
  }
  return $arreglo;
}
function mostrarIconos($array, $punto)
{
  echo '<div class="row" >';
  foreach ($array as $elemento1 => $valor1) {
    echo '<div class="col-6">';
    echo '<h4 class="pt-3">' . $elemento1 . '</h4>';
    echo '<ul class="foo">';
    foreach ($valor1 as $elemento2 => $valor2) {
      foreach ($valor2 as $elemento3 => $valor3) {
        switch ($elemento3) {
          case "href":
            $href = $valor3;
            break;
          case "target":
            $tar = $valor3;
            break;
          case "nombre":
            $titulo = $valor3;
            break;
          case "img":
            $img = $valor3;
            break;
          case "alt":
            $alt = $valor3;
            break;
        }
      }

      if ($elemento1 == "SIGANOS") {


        echo '<li>';
        echo '<a href="' . $href . '" target = "' . $tar . '" title = "' . $titulo . '">
       <img src = "' . $punto . $img . '" alt = "' . $alt . '" >'  . $titulo . '</a>';
        echo '</li>';
      }


      if ($elemento1 == "INFORAMACIÓN SOBRE LA TIENDA") {
        echo ' <p><span class="foor">' . $valor3 . '</span></p>';
      }
    }
    echo '</ul>';
    echo '</div>';
  }

  echo '</div>';
}

function corroborarInicio($nombre, $punto)
{
  if ($nombre) {
    echo   '<div class="p-2 "><a href="#"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">Registrarse </a></div>';
    echo   '<span>|</span>';
    echo    '<div class="p-2 "><a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal"> Iniciar Sesión</a></div>';
  } else {
    echo  '<div class="p-2 "><span class="text-white" > !hola¡' . $nombre . '</span></div>';
    echo '<div class="p-2 "><a href="<?php echo $punto ?>paginas/carrito.php?p=5"><img src="' . $punto . 'img/carrito.png" alt="" width="40" height="40"></a></div>';
  }
}
function menuCategorias($array, $punto)
{
  foreach ($array as $elemento => $valor) {
    foreach ($valor as $elemento1 => $valor1) {
      if ($elemento1 == "id_categoria") {
        $id = $valor1;
      }
      if ($elemento1 == "nombre") {
        echo '<div class="p-2"><a href="' . $punto . 'paginas/productos.php?p=2&id=' . $id . '">' . $valor1 . '</a></div>';
      }
    }
  }
}
function buscarSegunCat($cone,$id_cat){
  if ($cone) {
    $query = "SELECT p.id_detalle_producto as id_producto,p.nombre as nomProducto,p.descripcion,p.precio,c.id_categoria,c.nombre as nomcat,i.referencia
    from detalle_producto p
    inner join categoria c on p.id_categoria=c.id_categoria
    inner join imagenes l on p.id_detalle_producto=l.id_detalle_producto
    inner join img i on l.id_img=i.id_img
    where c.id_categoria=$id_cat
    group by p.id_detalle_producto";

    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_producto" => $row['id_producto'],
        "nomProducto" => $row['nomProducto'],
        "descripcion" => $row['descripcion'],
        "precio" => $row['precio'],
        "id_categoria" => $row['id_categoria'],
        "nomcat" => $row['nomcat'],
        "referencia" => $row['referencia']
      );
    }
  }
  return $arreglo;
}
function todosLosProductos($cone){
  if ($cone) {
    $query = "SELECT p.id_detalle_producto as id_producto,p.nombre as nomProducto,p.descripcion,p.precio,c.id_categoria,c.nombre as nomcat,i.referencia
    from detalle_producto p
    inner join categoria c on p.id_categoria=c.id_categoria
    inner join imagenes l on p.id_detalle_producto=l.id_detalle_producto
    inner join img i on l.id_img=i.id_img
    group by p.id_detalle_producto";

    $result = mysqli_query($cone, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_producto" => $row['id_producto'],
        "nomProducto" => $row['nomProducto'],
        "descripcion" => $row['descripcion'],
        "precio" => $row['precio'],
        "id_categoria" => $row['id_categoria'],
        "nomcat" => $row['nomcat'],
        "referencia" => $row['referencia']
      );
    }
  }
  return $arreglo;
}
function valoracion($num,$punto){
  $valoracion=$num/5;
  
  $d=0;
 
  while ($d< 5) {
    if ($valoracion > 1) {
      echo '<div><img src="'.$punto.'img/estre.png" width="40" height="auto"></div>';
     $valoracion=$valoracion - 1;
    } elseif ($valoracion > 0 and $valoracion < 1) {
      echo '<div><img src="'.$punto.'img/mediogris.png" width="40" height="auto"></div>';
      $valoracion = 0;
    } else {
      echo '<div><img src="'.$punto.'img/gris.png" width="40" height="auto"></div>';
    }
    $d++;
  }

}
function SegunDetalleYCat($con,$id_detalle_producto,$id_cat) {
  if ($con) {
    $query = "SELECT p.id_detalle_producto as id_producto,p.nombre as nomProducto,p.descripcion,p.precio,c.id_categoria,c.nombre as nomcat,i.referencia
    from detalle_producto p
    inner join categoria c on p.id_categoria=c.id_categoria
    inner join imagenes l on p.id_detalle_producto=l.id_detalle_producto
    inner join img i on l.id_img=i.id_img
    where c.id_categoria='$id_cat'
    group by p.id_detalle_producto
    limit 4";
    
    

    $result = mysqli_query($con, $query);
    $arreglo = array();
    while ($row = mysqli_fetch_array($result)) {
      $arreglo[] = array(
        "id_producto" => $row['id_producto'],
        "nomProducto" => $row['nomProducto'],
        "descripcion" => $row['descripcion'],
        "precio" => $row['precio'],
        "id_categoria" => $row['id_categoria'],
        "nomcat" => $row['nomcat'],
        "referencia" => $row['referencia']
      
      );
    }
  }
  return $arreglo;
}

function mostrar_productos($con){
  $cat = categorias($con);
  $index=1;
 
 
 
  for($i = 0; $i<count($cat); $i++) {
    $k = 0;
   echo '<div class="container contan text-light">';
   echo   '<div class="row">';
   echo  '<h2  class="pb-2 pt-2"> Los mas pedidos de '.$cat[$i]['nombre'].'</h2>';  
   while($k<4) {
    $productos =  SegunDetalleYCat($con,$k,$cat[$i]['id_categoria']);

    echo '
        <div class="col-3">
            <div class="card">
                <div class="card text-dark">
                    <img src="'.$productos[$k]['referencia'].'" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">'.$productos[$k]['nomProducto'].'</h5>
                        <p class="card-text">'. mb_substr($productos[$k]['descripcion'],0,20).'...</p>
                        <p class="card-text">Precio : '.$productos[$i]['precio'].'$</p>
                        <form action="paginas/detalle_producto.php">
                            <input type="hidden" name="pr" value="'.$productos[$k]['id_producto'].'">
                            <div class="d-flex "> 
                                <button type="submit" name='.'p'.' value="2" class="btn btn-primary">ver detalle</button>
                              <div class="cora"  id="'.$index.'"  onclick="damelike('.$index.')"><img  src="img/corazon2.png" alt="" width="40" height="40"></div>   
                        </div>
                           

                        </form>
                    </div>
                </div>
            </div>
            </div>';
        $k++;
        $index++;
        }
echo '
  </div><br>
  </div><br>';
      }
    }