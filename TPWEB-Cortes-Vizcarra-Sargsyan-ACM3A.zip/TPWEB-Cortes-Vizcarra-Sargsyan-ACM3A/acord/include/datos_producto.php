



<h2 class=""><?php echo $datos[0]['nombrep'];?></h2>
<P class="mt-4"><span id="precio">$ <?php echo $datos[0]['precio'];?></span><br>
    <div><span id="cuota">en 12 x $ <?php echo round(interes($datos[0]['precio']));?> </span></div>
</P>
<p class="mt-4"><span id="medios">Ver medios de pagos</span></p>
<div class="pt-4" id="pagos">
    <img src="../img/6.png" alt="" width="48" height="56">
    <img src="../img/5.png" alt="" width="48" height="56">
    <img src="../img/4.png" alt="" width="48" height="56">
    <img src="../img/3.png" alt="" width="40" height="35">
</div>
<p class="mt-4"><span id="stock">Stock disponible : <?php echo $datos[0]['cantidad'];?></span></p>
<p  id="cant"><span >cantidad :</span> <span id="cantidades"></span></p>
<form name="formulario" method="post" action="carrito.php?p=5">
<div class="pb-5 ran" ><label for="customRange2" class="form-label">Elija cantidad</label>
<input type="range"  onclick="cantidades()" class="form-range" min="0" max="<?php echo $datos[0]['cantidad']; ?>" id="customRange2"></div>
<div class="com"> <button type="submit" name="id_producto" value="<?php echo $datos[0]['id_detalle_producto'] ?>"  id="cepa" onclick='agregarItem(localStorage.getItem("id_usuario"),<?php echo $datos[0]["id_detalle_producto"] ?>)' class="botonCompra btn btn-primary mb-3">Comprar ahora</button></div>
</form>
<div class="estrella">
    <h3>Valoracion General</h3>
    <div class="d-flex estre">
    <?php echo valoracion($datos[0]['valoracion'],$punto) ?>
    </div>
</div>


