<div class="modal fade popo" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Registrate | si ya tenes una cuenta <span><a href="#" onclick="iniciarModal()" data-bs-toggle="modal" data-bs-target="#exampleModal" >Ingresa Aqui</a></span></h5>
                <button type="button" class="btn-close" onclick="resetear()" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class=""  name="registro"  method="post">

                    <label for="validationDefault01" class="form-label">Nombre</label>
                    <div class="row">
                        <div class="col-10">
                            <input type="text" name="nombre" class="form-control"  id="validationDefault01" >
                        </div>
                        <div class="col-2 " id="nom1"></div>
                        <div><label for="#" class="nom" id="nom2"></label></div>
                    </div>
                     
                    <label for="validationDefault02" class="form-label">Apellido</label>
                    <div class="row">
                        <div class="col-10">
                            <input type="text" class="form-control" name="apellido" id="validationDefault02" >
                        </div>
                        <div class="col-2" id="ape1"> </div>
                        <div>  <label for="#"  class="nom" id="ape2"></label></div>
                    </div>
                  
                    <label for="validationDefault03" class="form-label">Email</label>
                    <div class="row">
                        <div class="col-10">
                            <input type="email" class="form-control" name="email" id="validationDefault03" >
                        </div>
                        <div class="col-2" id="ema1"> </div>
                        <div><label for="#" class="nom" id="ema2"></label></div>
                    </div>
                    

                    <label for="validationDefault04" class="form-label">Clave</label>
                    <div class="row">
                        <div class="col-10">
                            <input type="password" id="obtener" name="clave"  class="form-control" id="validationDefault05" >
                        </div>
                        <div class="col-2" id="clav1"> </div>
                        <div><label for="#" id="clav2"></label></div>
                    </div>
                 


                    <label for="repetir" class="form-label">Repetir Clave</label>

                    <div class="row">
                        <div class="col-10">
                            <input type="password" id="repetir" onkeyup="coinciden()" class="form-control" >
                        </div>
                        <div class="col-2" id="repe1"></div>
                        <div> <label for="#" id="repe2"></label></div>
                    </div>
                 
                    <div class="col-12 pt-4">
                        <button type="button" class="btn btn-primary" onclick="cerrar()" >Regitrar</button>
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-secondary" onclick="resetear()" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>