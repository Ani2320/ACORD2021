
<div class="modal fade"  id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ingresá a Tu Cuenta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
         
                <form class="" name="iniciarSesion" method="post">


                    <div class="container col-11">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email</label>
                            <input type="email" class="form-control forma" id="exampleInputEmail1"  placeholder="Ingresa tu email" aria-describedby="emailHelp">

                        </div>
                        <div id="dat"></div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Clave</label>
                            <input type="password" class="form-control" placeholder="Ingresa tu contraseña" id="exampleInputPassword1">
                        </div>
                        <div id="confirm"></div>  
                        <div class="d-grid gap-2 col-8 mx-auto " id="bu"> <button type="button"  onclick="ingresarUsuario()" class="btn btn-primary"  >Ingresar</button></div>
                      
                    </div>




                    <p id="insertar"></p>

                </form>
            </div>
            <div class="modal-footer ju">
         
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>

            </div>
        </div>
    </div>
</div>
