<?php 

$categoria=categorias($con);
$pass=false;

foreach($categoria as $elemento =>$valor){
    echo '<ul>';
    foreach($valor as $elemento2 => $valor2){
      
      if($id_cat==0 && $elemento2=='nombre'){
           
       echo '<li>';
       echo  $valor2;
       echo '</li>';
   
      }else{
          if($elemento2=='id_categoria' && $id_cat==$valor2){
              $pass=true;
              }
              if($pass==true &&$elemento2=='nombre' ){
                echo '<li>';
                echo  $valor2;
                echo '</li>';
                $pass=false;
              }
      }

     }
     echo '</ul>';
}



?>