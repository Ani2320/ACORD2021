<?php
$indice = 1;
$punto = "";
$id_cat = 0;
if (isset($_GET['p'])) {
    $indice = $_GET['p'];
    if ($indice > 1) {
        $punto = "../";
    }
}
if (isset($_GET['id'])) {
    $id_cat = $_GET['id'];
}


$carpeta2 = $punto . "archivos_json/categorias.json";
$carpeta3 = $punto . "archivos_json/footer.json";
$categorias = LeerArrayJson($carpeta2);
$iconos = LeerArrayJson($carpeta3);
?>
<!doctype html>

<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caesar+Dressing&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $punto . "estilo/estilo.css" ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="<?php echo $punto . "js/inicio_storage.js" ?>"></script>


</head>