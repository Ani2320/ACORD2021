
$(document).ready(function () {

 

  
      

     $('#customRange2').click();


    







    var URLactual = jQuery(location).attr('href');
    nombre = localStorage.getItem('nombre');
    if (nombre == null) {
        texto = '<div class="p-2 "><a href="#"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">Registrarse </a></div>' +
            '<span>|</span>' +
            '<div class="p-2 "><a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal"> Iniciar Sesión</a></div>';

        document.getElementById('bienvenida').innerHTML = texto;

    } else {
        texto = '<div class="p-2 "><span class="text-white" > ! Hola  ' + nombre + ' ¡</span></div>';
        document.getElementById('bienvenida').innerHTML = texto;

        if (URLactual == 'http://localhost/acorde/index.php?p=1' || URLactual == 'http://localhost/acorde/index.php') {
            document.getElementById('nada').innerHTML = '<a href="paginas/carrito.php?p=5"><img src="img/carrito.png" alt="" width="40" height="40">';
            document.getElementById('nadados').innerHTML = ' <a href="#"><img src="img/usuario.png" alt="" width="53" height="53"></a>' +
                '<ul><li><a href="index.php">Tu perfil</a></li><li><a href="index.php" onclick="cerrarSesion()">Cerrrar sesion</a></li></ul>';
        } else {
            document.getElementById('nada').innerHTML = '<a href="../paginas/carrito.php?p=5"><img src="../img/carrito.png" alt="" width="40" height="40">';
            document.getElementById('nadados').innerHTML = ' <a href="#"><img src="../img/usuario.png" alt="" width="53" height="53"></a>' +
                '<ul><li><a href="../index.php">Tu perfil</a></li><li><a href="../index.php" onclick="cerrarSesion()">Cerrrar sesion</a></li></ul>';
        }
    }

});

