


var $ima = document.querySelectorAll('.colun');


$ima[0].addEventListener('mouseover', function () { cambiarfoto($ima[0].getAttribute('src')); });
$ima[1].addEventListener('mouseover', function () { cambiarfoto($ima[1].getAttribute('src')); });
$ima[2].addEventListener('mouseover', function () { cambiarfoto($ima[2].getAttribute('src')); });
$ima[3].addEventListener('mouseover', function () { cambiarfoto($ima[3].getAttribute('src')); });
$ima[4].addEventListener('mouseover', function () { cambiarfoto($ima[4].getAttribute('src')); });



document.addEventListener("DOMContentLoaded", () => {
  document.querySelector("#cepa").addEventListener("click", evento => {


    if(localStorage.getItem('nombre')==null){
          alert('debe Ingresar o Registrase para acceder al carrito');
       evento.preventDefault()
    }
         
      
  });
});



function cambiarfoto(parametro) {
  enlace = '<img src="' + parametro + '" alt=" "></img>';
  document.getElementById('bordegrande').innerHTML = enlace;
}

function eliminar(parametro) {
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "../consultas/eliminar_producto.php?id=" + parametro, true);
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      loadDoc();
    }
  };
  xhttp.send();


}

function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "../consultas/lista_carrito.php?id_usuario="+localStorage.getItem('id_usuario'), true);
  xhttp.send();
}









function agregarItem(id_usario, id_producto) {
 

 
  var xhttp = new XMLHttpRequest();

  xhttp.open("GET", "../consultas/agregar_item.php?id_usuario=" + id_usario + "&id_producto=" + id_producto, true);

  xhttp.send();









}


function agregarUsuario() {

  var nombre = document.getElementById('validationDefault01').value;
  var apellido = document.getElementById('validationDefault02').value;
  var email = document.getElementById('validationDefault03').value;
  var clave = document.getElementById('obtener').value;
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "consultas/registrar_usuario.php?nombre=" + nombre + "&apellido=" + apellido + "&email=" + email + "&clave=" + clave, true);
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var frm = document.registro;

      frm.submit();
    }
  };
  xhttp.send();
}


function verificarNombre() {
  var valor = true;
  var nombre = document.getElementById('validationDefault01').value;
  if (nombre == "") {
    document.getElementById('nom2').innerHTML = "este campo no puede estar vacio";
    document.getElementById('nom1').innerHTML = '<span class="xxx">x</span>';
    valor = false;
  } else {
    document.getElementById('nom2').innerHTML = "";
    document.getElementById('nom1').innerHTML = '<span class="ver">v</span>';
  }

  return valor;
}


function verificarApellido() {
  var valor = true;
  var apellido = document.getElementById('validationDefault02').value;
  if (apellido == "") {
    document.getElementById('ape2').innerHTML = "este campo no puede estar vacio";
    document.getElementById('ape1').innerHTML = '<span class="xxx">x</span>';
    valor = false;
  } else {
    document.getElementById('ape2').innerHTML = "";
    document.getElementById('ape1').innerHTML = '<span class="ver">v</span>';
  }
  return valor;
}

function verificarEmail() {
  var valor = true;
  var email = document.getElementById('validationDefault03').value;
  if (email == "") {
    document.getElementById('ema2').innerHTML = "este campo no puede estar vacio";
    document.getElementById('ema1').innerHTML = '<span class="xxx">x</span>';
    valor = false;
  } else {
    document.getElementById('ema2').innerHTML = "";
    document.getElementById('ema1').innerHTML = '<span class="ver">v</span>';
  }
  return valor;
}



function verificarClave() {
  var valor = true;
  var texto = document.getElementById('obtener').value;

  var menor = "";
  if (texto.length == 0 || texto.length < 6) {
    document.getElementById('clav2').innerHTML = '<p class="nom">la clave tiene que ser mayor o igual a 6 caracteres</p>';
    document.getElementById('clav1').innerHTML = '<span class="xxx">x</span>';
    valor = false;
  } else {
    document.getElementById('clav2').innerHTML = "";
    document.getElementById('clav1').innerHTML = '<span class="ver">v</span>';
  }

  return valor;

}

function coinciden() {
  var valor = true;
  var texto = "las claves no coinciden o el campo esta vacio";
  var texto1 = document.getElementById('obtener').value;
  var texto2 = document.getElementById('repetir').value;

  if (texto1 != texto2 || texto1 == "") {
    document.getElementById('repe2').innerHTML = texto;
    document.getElementById('repe1').innerHTML = '<span class="xxx">x</span>';
    valor = false;
  } else {
    document.getElementById('repe2').innerHTML = "";
    document.getElementById('repe1').innerHTML = '<span class="ver">v</span>';
  }
  return valor;

}

function cerrar() {

  if (verificarNombre() && verificarApellido() && verificarEmail() && verificarClave() && coinciden()) {
    agregarUsuario();
  } else {

    verificarNombre()
    verificarApellido()
    verificarEmail()
    verificarClave()
    coinciden();
  }

}

function resetear() {
  document.getElementById('nom2').innerHTML = "";
  document.getElementById('nom1').innerHTML = "";
  document.getElementById('ape2').innerHTML = "";
  document.getElementById('ape1').innerHTML = "";
  document.getElementById('ema2').innerHTML = "";
  document.getElementById('ema1').innerHTML = "";
  document.getElementById('clav2').innerHTML = "";
  document.getElementById('clav1').innerHTML = "";
  document.getElementById('repe2').innerHTML = "";
  document.getElementById('repe1').innerHTML = "";
}

function iniciarModal() {
  document.getElementById('close').click();
}
function ingresarUsuario() {
  var email = document.getElementById('exampleInputEmail1').value;
  var usuario = buscarUsuario(email);
  var usu;


  if (usuario == "") {
    document.getElementById('dat').innerHTML = "El email no se encuentra registrado en ninguna cuenta";
  } else if (validarClaveUsuario(usuario) == "") {
    document.getElementById('confirm').innerHTML = "la clave es incorrecta o no existe";
    document.getElementById('dat').innerHTML = "";

  } else {
    var URLactual = jQuery(location).attr('href');
    usu = validarClaveUsuario(usuario);
    texto=    '<div class="p-2 "><span class="text-white" > ! Hola  '+usu['nombre']+' ¡</span></div>';
    document.getElementById('bienvenida').innerHTML=texto;

    if( URLactual=='http://localhost/acorde/index.php?p=1'|| URLactual=='http://localhost/acorde/index.php'){
        document.getElementById('nada').innerHTML='<a href="paginas/carrito.php?p=5"><img src="img/carrito.png" alt="" width="40" height="40">';
        document.getElementById('nadados').innerHTML=' <a href="#"><img src="img/usuario.png" alt="" width="53" height="53"></a>'+
            '<ul><li><a href="index.php">Tu perfil</a></li><li><a href="index.php" onclick="cerrarSesion()">Cerrrar sesion</a></li></ul>';
    }else{
        document.getElementById('nada').innerHTML='<a href="../paginas/carrito.php?p=5"><img src="../img/carrito.png" alt="" width="40" height="40">';
        document.getElementById('nadados').innerHTML=' <a href="#"><img src="../img/usuario.png" alt="" width="53" height="53"></a>'+
        '<ul><li><a href="../index.php">Tu perfil</a></li><li><a href="../index.php" onclick="cerrarSesion()">Cerrrar sesion</a></li></ul>';
    }

  
    $('#exampleModal').modal('hide');
    localStorage.setItem("nombre", usu['nombre']);
    localStorage.setItem("id_usuario", usu['id_usuario']);


  }
}

function validarClaveUsuario(obj) {
  var clave = document.getElementById('exampleInputPassword1').value;
  var usuario = "";
  obj.forEach((usu) => {

    if (usu['clave'] == clave) {
      usuario = usu;
    }
  });
  return usuario;

}


function buscarUsuario(email) {

  var usuario = $.ajax({
    url: 'http://localhost/acorde/consultas/buscarUsuario.php?email=' + email, //indicamos la ruta donde se genera la hora
    dataType: 'json', //indicamos que es de tipo texto plano
    async: false //ponemos el parámetro asyn a falso
  }).responseText;


  var obj = $.parseJSON(usuario);
  return obj;

}



function cerrarSesion(){
  localStorage.clear("nombre");

  texto= '<div class="p-2 "><a href="#"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">Registrarse </a></div>'+
  '<span>|</span>'+
  '<div class="p-2 "><a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal"> Iniciar Sesión</a></div>';

document.getElementById('bienvenida').innerHTML=texto;
document.getElementById('nada').innerHTML="";
document.getElementById('nadados').innerHTML="";
}

function damelike(){
 var num=localStorage.getItem('like');
 if(num==0){
 
   localStorage.setItem('like',1);
   document.getElementById('corazo').innerHTML='<img  src="img/corazon2.png" alt="" width="40" height="40">';
 }else{
 
  localStorage.setItem('like',0);
  document.getElementById('corazo').innerHTML='<img  src="img/corazon1.png" alt="" width="40" height="40">';
 }


}
function cantidades(){
  valo=document.getElementById('customRange2').value;
  document.getElementById('cantidades').innerHTML=valo;
}

function insertarEstado(){
 localStorage.setItem('like',1);
  document.getElementById('probando').innerHTML=localStorage.getItem('like');
}
function mensajeContacto(){
   var nombre=document.getElementById('nombrecon').value;
   var email=document.getElementById('emailcon').value;
   var asunto=document.getElementById('asunto').value;
   var mensaje=document.getElementById('mensaje').value;
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "../consultas/form_procesar.php?nombre="+nombre+'&email='+email+'&asunto='+asunto+'&mensaje='+mensaje, true);
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('nombrecon').value=""; 
      document.getElementById('emailcon').value=""; 
      document.getElementById('asunto').value=""; 
      document.getElementById('mensaje').value=""; 
 
    }
  };
  xhttp.send();
}
function limpiarContacto(){
  document.getElementById('nombrecon').innerText="";

}