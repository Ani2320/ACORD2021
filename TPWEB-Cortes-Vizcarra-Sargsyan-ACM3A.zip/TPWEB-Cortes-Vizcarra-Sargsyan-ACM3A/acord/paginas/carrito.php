<?php
require_once("../consultas/coneccion.php");
require_once("../include/funciones.php");
require_once("../include/1head.php");
require_once("../include/2header.php");
require_once("../include/form_registro_usuario.php");
require_once("../include/form_ingreso_usuario.php");

?>

<main class="container">
    <div>
        <h2>Mi carrito</h2>
    </div>
    <hr>
    <div class="row">
        <div class="col-9">

            <div id="demo">
            </div>
           
        </div>
        <div class="col-3">
            <div class="resumen">
                <div>
                    <h3>Resumen</h3>
                 </div>
                <hr>
                <div ><button type="button" class="btn btn-secondary confi" >Continuar comprando</button></div>
                <div><button type="button" class="btn btn-success confi" onclick="loadDoc()">Confirmar Compra</button> </div>
                <div id="buscar">

                </div>
               
            </div>
        </div>
    </div>

</main>

<?php require_once("../include/footer.php");  ?>
</body>

</html>