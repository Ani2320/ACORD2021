<?php
require_once("../consultas/coneccion.php");
require_once("../include/funciones.php");
require_once("../include/1head.php");
require_once("../include/2header.php");
require_once("../include/form_registro_usuario.php");
require_once("../include/form_ingreso_usuario.php");


if (isset($_GET['pr'])) {
    $id_producto = $_GET['pr'];
}
$imagenes = referencia($con, $id_producto);
$datos = detalle($con, $id_producto);
?>
<main>
    <div class="container detalle">
        <div class="row pb-3 pt-3">

            <div class="col-7">

                <div class="row">

                    <div class="col-3 columna">
                        <?php columa_img($imagenes, $punto); ?>

                    </div>
                    <div class="col-9 ">
                        <div id="bordegrande"><img src="<?php echo $punto . $imagenes[4]['referencia']; ?>" alt=""></div>
                    </div>

                </div>

                <hr class="linea">

                <section class="pb-4">
                    <div>
                        <h3>Descripcion</h3>
                        <?php echo ' <P> ' . $datos[0]['descripcion'] . ' </P>' ?>
                    </div>
                </section>

            </div>
            <div class="vertical col-1">

</div>
            <div class="col-4 ">
                
                <div class="descrip bg-light">
                    <div class="dapro">
                        <?php require_once("../include/datos_producto.php") ?>
                    </div>


                </div>
            </div>


        </div>

    </div>
</main>
<?php require_once("../include/footer.php");  ?>

</body>

</html>