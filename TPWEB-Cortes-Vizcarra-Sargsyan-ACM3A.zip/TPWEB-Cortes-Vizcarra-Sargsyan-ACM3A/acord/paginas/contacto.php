<?php 
require_once("../consultas/coneccion.php");
require_once("../include/funciones.php");
require_once("../include/1head.php");
require_once("../include/2header.php");
require_once("../include/form_registro_usuario.php");
require_once("../include/form_ingreso_usuario.php");

?>



<body>

    <div class="container pb-4">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6 bg-light form-demo rounded mt-5">
                <h1 class= "pt-2 text-center text-dark">Formulario de contacto</h1>
                <hr class="bg-light w-75">
              
             <div class="p-2"><input type="text" class="form-control" name="nombre" id="nombrecon" placeholder="nombre" ></div>   
        <div class="p-2"> <input type="email" class="form-control" name="email" id="emailcon" placeholder="email" ></div>       
          <div class="p-2"> <input type="text" class="form-control" name="asunto" id="asunto" placeholder="asunto" ></div>     
           <div class="p-2"><textarea name="mensaje" id="mensaje" cols="85" rows="5" placeholder="Escriba aqui su mensaje"></textarea></div>    
                   
                <div class="p-2"><button  onclick="mensajeContacto()" class="btn btn-primary">Enviar</button></div>    
             
            </div>
        </div>
    </div>

   







<?php

   require_once("../include/footer.php");
     
   ?>
</body>
</html>