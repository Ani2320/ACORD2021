<?php
require_once("../consultas/coneccion.php");
require_once("../include/funciones.php");
require_once("../include/1head.php");
require_once("../include/2header.php");
require_once("../include/form_registro_usuario.php");
require_once("../include/form_ingreso_usuario.php");

?>

<span></span>


<main>
   <div class=" container">
      <div class="row">


         <div class="col-3 catlista">

         <?php require_once('../include/categorias.php'); ?>
        

         </div>


         <div class="col-9">
            <div class="container">


               <div class="row">

                  <?php require_once('../consultas/mostrarSegunCategoria.php'); ?>


               </div>

            </div>
         </div>



      </div>
   </div>
</main>













































































<?php
require_once("../include/footer.php");

?>
</body>

</html>