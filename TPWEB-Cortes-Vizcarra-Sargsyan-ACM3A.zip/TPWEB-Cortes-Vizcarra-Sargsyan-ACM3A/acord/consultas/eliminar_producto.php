<?php
require_once('coneccion.php');
require_once("../include/funciones.php");
$id=$_REQUEST['id'];
$query1 = "DELETE from posibles_compras  where id_posibles_compras=$id";
mysqli_query($con, $query1);

?>