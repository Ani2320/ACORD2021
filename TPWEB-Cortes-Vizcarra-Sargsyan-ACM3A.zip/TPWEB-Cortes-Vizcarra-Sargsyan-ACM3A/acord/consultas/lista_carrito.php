<?php 
require_once('coneccion.php');
require_once("../include/funciones.php");
$id_usuario=$_REQUEST['id_usuario'];
  $array = buscar_lista_compra($con,$id_usuario);
  for ($i = 0; $i <count($array); $i++) {
    $array2 = referencia($con, $array[$i]['id_detalle_producto']);
    echo '<div class="comprafutura d-flex pt-3 pl-3 ">';
    echo '<div class="chiqui ml-5"><img src="../'. $array2[0]['referencia'] . '" width="60" height="60" alt=""></div>';
    echo '<div class=" til ml-5"><a href="detalle_producto.php?p=2&pr=' . $array[$i]['id_detalle_producto'] . '"><span>' . $array[$i]['nombrep'] . '</span></a></div>';
    echo '<div class=" flex-colum ml-5 prepre">';
    echo '<div> <span>Precio:</span></div>';
    echo '<div> <span> ' . $array[$i]['precio'] . '</span></div>';
    echo '</div>';
    echo '<div class=" flex-colum ml-5 canti">';
    echo '<div> <span>Cantidad:</span></div>';
    echo '<div> <span>$' . $array[$i]['precio'] . '</span></div>';
    echo '</div>';
    echo '<div class=" flex-colum ml-5 subt">';
    echo '<div> <span>SubTotal:</span></div>';
    echo '<div> <span>$' . $array[$i]['precio'] . '</span></div>';
    echo '</div>';
    echo ' <div class="elim"><button type="button" class="btn btn-danger" onclick="eliminar('.$array[$i]['id_posibles_compras'].')" >x</button></div>';
    echo '</div>';
  
  }


 



?>