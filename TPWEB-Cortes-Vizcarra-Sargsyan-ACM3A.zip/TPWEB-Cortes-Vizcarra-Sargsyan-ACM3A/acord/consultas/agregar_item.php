<?php
require_once('coneccion.php');
require_once("../include/funciones.php");
$id_usuario=$_REQUEST['id_usuario'];
$id_producto=$_REQUEST['id_producto'];
$query1 = "INSERT into posibles_compras values(0,$id_usuario,$id_producto)";
mysqli_query($con, $query1);

?>