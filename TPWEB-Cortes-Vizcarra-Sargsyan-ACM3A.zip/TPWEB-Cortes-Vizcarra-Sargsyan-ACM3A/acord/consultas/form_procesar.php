<?php

require_once('coneccion.php');
require_once("../include/funciones.php");
$nombre=$_REQUEST['nombre'];
$email=$_REQUEST['email'];
$asunto=$_REQUEST['asunto'];
$mensaje=$_REQUEST['mensaje'];
$fechareg = date("d/m/y");
$consulta = "INSERT INTO contacto VALUES (0,'$nombre','$email','$asunto','$mensaje','$fechareg')";

mysqli_query($con, $consulta);

?>
