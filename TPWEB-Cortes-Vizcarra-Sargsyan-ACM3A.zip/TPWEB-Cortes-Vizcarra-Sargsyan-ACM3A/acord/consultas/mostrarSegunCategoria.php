<?php

$index=1;
if($id_cat==0){
   $productos=todosLosProductos($con); 
}else{
 $productos = buscarSegunCat($con, $id_cat);   
}

for ($i = 0; $i < count($productos); $i++) {
   echo '
        <div class="col-3" >
            <div class="card mt-4">
                <div class="card text-dark">
                    <img src="'.$punto.$productos[$i]['referencia'].'" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">'.$productos[$i]['nomProducto'].'</h5>
                        <p class="card-text">'. mb_substr($productos[$i]['descripcion'],0,20).'...</p>
                        <p class="card-text">Precio : '.$productos[$i]['precio'].'$</p>
                        <form action="'.$punto.'paginas/detalle_producto.php">
                            <input type="hidden" name="pr" value="'.$productos[$i]['id_producto'].'">
                            <div class="d-flex "> 
                                <button type="submit" name='.'p'.' value="2" class="btn btn-primary">ver detalle</button>
                              <div class="cora"  id="'.$index.'"  onclick="damelike('.$index.')"><img  src="'.$punto.'img/corazon2.png" alt="" width="40" height="40"></div>   
                        </div>
                           

                        </form>
                    </div>
                </div>
            </div>
            </div>';
 
      
}
