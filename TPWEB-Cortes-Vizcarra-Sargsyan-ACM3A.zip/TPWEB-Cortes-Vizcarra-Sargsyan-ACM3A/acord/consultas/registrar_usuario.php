<?php
require_once('coneccion.php');
require_once("../include/funciones.php");
$nombreUsu=$_GET['nombre'];
$apellidoUsu=$_GET['apellido'];
$emailUsu=$_GET['email'];
$claveUsu=$_GET['clave'];

$query1 = "INSERT into usuario values(0,'$nombreUsu','$apellidoUsu','$emailUsu','$claveUsu')";
mysqli_query($con, $query1);
?>