<?php
$email=$_REQUEST['email'];
require_once('coneccion.php');
require_once('../include/funciones.php');
$usuarios=buscarUsuario($con,$email);

echo json_encode($usuarios);
?>