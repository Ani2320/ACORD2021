-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema proyectoAcord
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `proyectoAcord` ;

-- -----------------------------------------------------
-- Schema proyectoAcord
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `proyectoAcord` DEFAULT CHARACTER SET utf8 ;
USE `proyectoAcord` ;

-- -----------------------------------------------------
-- Table `menu`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `menu` ;

CREATE TABLE IF NOT EXISTS `menu` (
  `id_menu` INT NOT NULL AUTO_INCREMENT,
  `referencia` VARCHAR(45) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_menu`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `categoria`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `categoria` ;

CREATE TABLE IF NOT EXISTS `categoria` (
  `id_categoria` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_categoria`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `detalle_producto`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `detalle_producto` ;

CREATE TABLE IF NOT EXISTS `detalle_producto` (
  `id_detalle_producto` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `descripcion` VARCHAR(200) NOT NULL,
  `precio` DOUBLE NOT NULL,
  `id_categoria` INT NOT NULL,
  `valoracion` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_detalle_producto`),
  CONSTRAINT `fk_categoria1`
    FOREIGN KEY (`id_categoria`)
    REFERENCES `categoria` (`id_categoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `img`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `img` ;

CREATE TABLE IF NOT EXISTS `img` (
  `id_img` INT NOT NULL AUTO_INCREMENT,
  `referencia` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_img`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `imagenes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `imagenes` ;

CREATE TABLE IF NOT EXISTS `imagenes` (
  `id_imagenes` INT NOT NULL,
  `id_detalle_producto` INT NOT NULL,
  `id_img` INT NOT NULL,
  PRIMARY KEY (`id_imagenes`),
  CONSTRAINT `fk_detalle_producto`
    FOREIGN KEY (`id_detalle_producto`)
    REFERENCES `detalle_producto` (`id_detalle_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_img1`
    FOREIGN KEY (`id_img`)
    REFERENCES `img` (`id_img`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `almacen`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `almacen` ;

CREATE TABLE IF NOT EXISTS `almacen` (
  `id_almacen` INT NOT NULL AUTO_INCREMENT,
  `id_detalle_producto` INT NOT NULL,
  `cantidad` INT NOT NULL,
  PRIMARY KEY (`id_almacen`),
  CONSTRAINT `fk_detalle_producto1`
    FOREIGN KEY (`id_detalle_producto`)
    REFERENCES `detalle_producto` (`id_detalle_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `usuario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `usuario` ;

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `clave` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_usuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `posibles_compras`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `posibles_compras` ;

CREATE TABLE IF NOT EXISTS `posibles_compras` (
  `id_posibles_compras` INT NOT NULL AUTO_INCREMENT,
  `id_usuario` INT NOT NULL,
  `id_detalle_producto` INT NOT NULL,
  PRIMARY KEY (`id_posibles_compras`),
  CONSTRAINT `fk_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `usuario` (`id_usuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_producto2`
    FOREIGN KEY (`id_detalle_producto`)
    REFERENCES `detalle_producto` (`id_detalle_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `menu`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `menu` (`id_menu`, `referencia`, `nombre`) VALUES (1, 'index.php', 'Home');
INSERT INTO `menu` (`id_menu`, `referencia`, `nombre`) VALUES (2, 'paginas/productos.php', 'Productos');
INSERT INTO `menu` (`id_menu`, `referencia`, `nombre`) VALUES (3, 'paginas/contacto.php', 'Contacto');

COMMIT;


-- -----------------------------------------------------
-- Data for table `categoria`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `categoria` (`id_categoria`, `nombre`) VALUES (1, 'Instrumentos De Cuerda');
INSERT INTO `categoria` (`id_categoria`, `nombre`) VALUES (2, 'Instrumento De Percucion');
INSERT INTO `categoria` (`id_categoria`, `nombre`) VALUES (3, 'Instrumento De Viento');

COMMIT;


-- -----------------------------------------------------
-- Data for table `detalle_producto`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (1, 'Guitarra Criolla', '-Varios colores para elegir</br> -Clavijas de calidad</br> -Puente de madera</br> -Cuerdas de nylon</br>  -Incluye funda y púa.', 3200, 1, '25');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (2, 'Bateria', 'jajajaaja', 4000, 2, '15');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (3, 'Afinador', 'El último software de Cherub para una afinación rápida, precisa y estable', 5000, 1, '20');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (4, 'Clarinete', 'descripcion de clarinete', 6000, 3, '24');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (5, 'Guitarra electrica', 'descripcion de Guitarra electrica', 4500, 1, '12');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (6, 'Bateria kids', 'descripcion de Bateria kids', 2561, 2, '25');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (7, 'Bajo', 'descripcion Bajo', 4561, 1, '24');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (8, 'Guitarra Criolla', 'descripcion Guitarra Criolla', 5123, 1, '15');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (9, 'Contrafagot', 'descripcion Contrafagot', 4512, 3, '16');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (10, 'Corno', 'descripcion Corno', 1234, 3, '25');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (11, 'Flauta', 'descripcion de la Flauta', 3546, 3, '21');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (12, 'Bateria Electronica', 'descripcion Bateria Electronica', 5429, 2, '15');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (13, 'Saxo', 'descripcion de saxo', 4612, 3, '25');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (14, 'Bateria', 'descripcion Bateria', 8459, 2, '15');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (15, 'Tuba', 'descripcion Tuba', 4512, 3, '25');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (16, 'Trompeta', 'descripcion trompeta', 7415, 3, '15');
INSERT INTO `detalle_producto` (`id_detalle_producto`, `nombre`, `descripcion`, `precio`, `id_categoria`, `valoracion`) VALUES (17, 'Platillo', 'descripcion Platillo', 5641, 2, '25');

COMMIT;


-- -----------------------------------------------------
-- Data for table `img`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `img` (`id_img`, `referencia`) VALUES (1, 'img/guitarra1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (2, 'img/guitarra2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (3, 'img/guitarra3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (4, 'img/guitarra4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (5, 'img/guitarra5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (6, 'img/bateria1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (7, 'img/bateria2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (8, 'img/bateria3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (9, 'img/bateria4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (10, 'img/bateria5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (11, 'img/afinador1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (12, 'img/afinador2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (13, 'img/afinador3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (14, 'img/afinador4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (15, 'img/afinador5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (16, 'img/clarinete1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (17, 'img/clarinete2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (18, 'img/clarinete3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (19, 'img/clarinete4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (20, 'img/clarinete5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (21, 'img/electrica1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (22, 'img/electrica2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (23, 'img/electrica3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (24, 'img/electrica4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (25, 'img/electrica5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (26, 'img/batechico1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (27, 'img/batechico2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (28, 'img/batechico3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (29, 'img/batechico4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (30, 'img/batechico5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (31, 'img/bajo1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (32, 'img/bajo2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (33, 'img/bajo3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (34, 'img/bajo4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (35, 'img/bajo5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (36, 'img/criolla1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (37, 'img/criolla2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (38, 'img/criolla3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (39, 'img/criolla4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (40, 'img/criolla5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (41, 'img/contrafagot1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (42, 'img/contrafagot2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (43, 'img/contrafagot3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (44, 'img/contrafagot4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (45, 'img/contrafagot5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (46, 'img/corno1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (47, 'img/corno2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (48, 'img/corno3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (49, 'img/corno4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (50, 'img/corno5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (51, 'img/flauta1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (52, 'img/flauta2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (53, 'img/flauta3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (54, 'img/flauta4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (55, 'img/flauta5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (56, 'img/electronica1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (57, 'img/electronica2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (58, 'img/electronica3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (59, 'img/electronica4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (60, 'img/electronica5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (61, 'img/saxo1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (62, 'img/saxo2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (63, 'img/saxo3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (64, 'img/saxo4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (65, 'img/saxo5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (66, 'img/tambor1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (67, 'img/tambor2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (68, 'img/tambor3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (69, 'img/tambor4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (70, 'img/tambor5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (71, 'img/tuba1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (72, 'img/tuba2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (73, 'img/tuba3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (74, 'img/tuba4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (75, 'img/tuba5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (76, 'img/trompeta1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (77, 'img/trompeta2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (78, 'img/trompeta3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (79, 'img/trompeta4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (80, 'img/trompeta5.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (81, 'img/platillo1.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (82, 'img/platillo2.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (83, 'img/platillo3.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (84, 'img/platillo4.png');
INSERT INTO `img` (`id_img`, `referencia`) VALUES (85, 'img/platillo5.png');

COMMIT;


-- -----------------------------------------------------
-- Data for table `imagenes`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (1, 1, 1);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (2, 1, 2);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (3, 1, 3);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (4, 1, 4);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (5, 1, 5);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (6, 2, 6);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (7, 2, 7);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (8, 2, 8);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (9, 2, 9);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (10, 2, 10);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (11, 3, 11);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (12, 3, 12);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (13, 3, 13);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (14, 3, 14);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (15, 3, 15);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (16, 4, 16);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (17, 4, 17);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (18, 4, 18);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (19, 4, 18);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (20, 4, 20);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (21, 5, 21);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (22, 5, 22);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (23, 5, 23);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (24, 5, 24);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (25, 5, 25);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (26, 6, 26);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (27, 6, 27);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (28, 6, 28);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (29, 6, 29);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (30, 6, 30);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (31, 7, 31);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (32, 7, 32);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (33, 7, 33);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (34, 7, 34);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (35, 7, 35);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (36, 8, 36);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (37, 8, 37);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (38, 8, 38);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (39, 8, 39);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (40, 8, 40);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (41, 9, 41);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (42, 9, 42);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (43, 9, 43);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (44, 9, 44);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (45, 9, 45);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (46, 10, 46);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (47, 10, 47);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (48, 10, 48);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (49, 10, 49);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (50, 10, 50);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (51, 11, 51);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (52, 11, 52);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (53, 11, 53);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (54, 11, 54);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (55, 11, 55);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (56, 12, 56);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (57, 12, 57);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (58, 12, 58);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (59, 12, 59);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (60, 12, 60);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (61, 13, 61);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (62, 13, 62);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (63, 13, 63);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (64, 13, 64);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (65, 13, 65);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (66, 14, 66);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (67, 14, 67);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (68, 14, 68);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (69, 14, 69);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (70, 14, 70);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (71, 15, 71);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (72, 15, 72);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (73, 15, 73);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (74, 15, 74);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (75, 15, 75);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (76, 16, 76);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (77, 16, 77);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (78, 16, 78);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (79, 16, 79);
INSERT INTO `imagenes` (`id_imagenes`, `id_detalle_producto`, `id_img`) VALUES (80, 16, 80);

COMMIT;


-- -----------------------------------------------------
-- Data for table `almacen`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (1, 1, 10);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (2, 2, 15);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (3, 3, 20);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (4, 4, 32);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (5, 5, 12);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (6, 6, 25);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (7, 7, 26);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (8, 8, 24);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (9, 9, 28);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (10, 10, 20);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (11, 11, 23);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (12, 12, 26);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (13, 13, 32);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (14, 14, 40);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (15, 15, 12);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (16, 16, 25);
INSERT INTO `almacen` (`id_almacen`, `id_detalle_producto`, `cantidad`) VALUES (17, 17, 24);

COMMIT;


-- -----------------------------------------------------
-- Data for table `usuario`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `email`, `clave`) VALUES (1, 'luis', 'cortes', 'caporin@hotmail.com', 'providenza');
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `email`, `clave`) VALUES (2, 'cristina', 'miamor', 'corazon@gmail.com', 'corazon');

COMMIT;


-- -----------------------------------------------------
-- Data for table `posibles_compras`
-- -----------------------------------------------------
START TRANSACTION;
USE `proyectoAcord`;
INSERT INTO `posibles_compras` (`id_posibles_compras`, `id_usuario`, `id_detalle_producto`) VALUES (1, 1, 1);
INSERT INTO `posibles_compras` (`id_posibles_compras`, `id_usuario`, `id_detalle_producto`) VALUES (2, 1, 2);

COMMIT;

